"""This example turns on the little red LED."""
from adafruit_circuitplayground import cp

while True:
    cp.red_led = True
